package im.zhaojun.common.exception;

public class AuthcTypeNotSupportException extends RuntimeException {

    private static final long serialVersionUID = -8964524099437750622L;

    public AuthcTypeNotSupportException(String message) {
        super(message);
    }

}
