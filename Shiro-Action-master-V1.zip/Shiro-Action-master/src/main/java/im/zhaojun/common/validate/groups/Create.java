package im.zhaojun.common.validate.groups;

import javax.validation.groups.Default;

public interface Create extends Default {
}