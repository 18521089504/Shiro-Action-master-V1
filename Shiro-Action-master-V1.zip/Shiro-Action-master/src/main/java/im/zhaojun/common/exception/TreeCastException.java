package im.zhaojun.common.exception;

public class TreeCastException extends RuntimeException {
    private static final long serialVersionUID = -7358633666514111106L;

    public TreeCastException(Throwable cause) {
        super(cause);
    }
}
