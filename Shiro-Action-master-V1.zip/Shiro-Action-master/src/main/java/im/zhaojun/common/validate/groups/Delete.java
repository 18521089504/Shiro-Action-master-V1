package im.zhaojun.common.validate.groups;

import javax.validation.groups.Default;

public interface Delete extends Default {
}